package com.seclore.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.seclore.main.domain.MemberDetails;
import com.seclore.main.repository.MemberRepositoryInterface;

@Component
public class MemberService implements MemberServiceInterface {

	@Autowired
	private MemberRepositoryInterface memberRepository;
	
	@Override
	public boolean addNewMember(MemberDetails member) {
		// TODO Auto-generated method stub
		return memberRepository.addNewMember(member);
	}

	@Override
	public List<MemberDetails> getAllMembers() {
		// TODO Auto-generated method stub
		return memberRepository.getAllMembers();
	}

	@Override
	public MemberDetails getSingleMember(int memberId) {
		// TODO Auto-generated method stub
		return memberRepository.getSingleMember(memberId);
	}

	@Override
	public boolean removeMember(int memberId) {
		// TODO Auto-generated method stub
		return memberRepository.removeMember(memberId);
	}

	@Override
	public boolean updateMember(MemberDetails member) {
		// TODO Auto-generated method stub
		return memberRepository.updateMember(member);
	}

}

package com.seclore.main.controller.rest;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.seclore.main.domain.BookDetails;
import com.seclore.main.service.BookServiceInterface;

@RestController
@RequestMapping("/bookcrudapi")
public class BookControllerRest {

    @Autowired
    private BookServiceInterface bookService;

    @RequestMapping(value = "books", method = RequestMethod.POST)
    public boolean saveUpdatedBookDetails(@RequestBody BookDetails book) {
        System.out.println("Inside Save updated book method: " + book.getBookId());
        return bookService.updateBook(book);
    }

    @RequestMapping(value = "books/{bookId}", method = RequestMethod.GET)
    public BookDetails getBookDetails(@PathVariable int bookId) {
        System.out.println("Inside Get Book Details method");
        return bookService.getSingleBook(bookId);
    }

    @RequestMapping(value = "books/{bookId}", method = RequestMethod.DELETE)
    public boolean deleteBookDetails(@PathVariable int bookId) {
        System.out.println("Inside Delete method");
        return bookService.removeBook(bookId);
    }

    @RequestMapping(value = "books", method = RequestMethod.POST)
    public boolean saveBookDetails(@RequestBody BookDetails book) {
        return bookService.addNewBook(book);
    }

    @RequestMapping(value = "books", method = RequestMethod.GET)
    public List<BookDetails> getAllBooks() {
        List<BookDetails> bookList = bookService.getAllBooks();
        System.out.println(bookList);
        return bookList;
    }
}

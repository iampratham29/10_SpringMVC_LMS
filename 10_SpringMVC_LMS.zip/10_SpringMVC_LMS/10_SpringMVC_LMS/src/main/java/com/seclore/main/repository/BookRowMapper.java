/**
 * 
 */
package com.seclore.main.repository;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.seclore.main.domain.BookDetails;

/**
 * 
 */
public class BookRowMapper implements RowMapper<BookDetails> {
	
	public BookDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
		int bookId = rs.getInt("book_id");
		String title = rs.getString("book_title");
		String author = rs.getString("book_author");
		boolean issuable = rs.getBoolean("book_issuable"); 
		
		BookDetails book = new BookDetails(bookId, title, author, issuable);
		return book;
	}

}

/**
 * 
 */
package com.seclore.main.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.seclore.main.domain.BookDetails;

/**
 * 
 */
@Component
public class BookRepository implements BookRepositoryInterface {

	@Autowired
	private JdbcTemplate jdbcTemplate;
			
	private static final String ADD_NEW_BOOK = "Insert into book_details(book_author, book_issuable, book_title) values(?,?,?)";
	private static final String SELECT_ALL_BOOKS = "Select * from book_details";
	private static final String SELECT_ONE_BOOK = "Select * from book_details Where book_id=?";
	private static final String REMOVE_ONE_BOOK = "DELETE from book_details Where book_id=?";
	private static final String UPDATE_BOOK = "Update book_details Set book_title =? , book_author=?, book_issuable=? Where book_id=?";

	

	
	@Override
	public boolean addNewBook(BookDetails book) {
		Object[] args = {  book.getAuthor(), book.isIssuable(), book.getTitle() };
		int count = jdbcTemplate.update(ADD_NEW_BOOK,args);
		if(count>0)
		{
			return true;
		}
		return false;
	}

	@Override
	public List<BookDetails> getAllBooks() {
		// TODO Auto-generated method stub
		List<BookDetails> bookList = jdbcTemplate.query(SELECT_ALL_BOOKS, new BookRowMapper());
		return bookList;
	}

	@Override
	public BookDetails getSingleBook(int bookId) {
		// TODO Auto-generated method stub
		BookDetails book = jdbcTemplate.queryForObject(SELECT_ONE_BOOK, new BookRowMapper(),bookId);
		return book;
	}

	@Override
	public boolean removeBook(int bookId) {
		// TODO Auto-generated method stub
		int result = jdbcTemplate.update(REMOVE_ONE_BOOK, bookId);
		
		return result>0;
	}

	@Override
	public boolean updateBook(BookDetails book) {
		Object[] args = {book.getTitle(),book.getAuthor(),book.isIssuable(),book.getBookId()};
		int result = jdbcTemplate.update(UPDATE_BOOK, args);
		return result>0;
	}

}

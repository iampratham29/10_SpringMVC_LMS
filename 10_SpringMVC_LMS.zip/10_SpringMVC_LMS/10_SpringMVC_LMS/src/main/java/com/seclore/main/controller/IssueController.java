package com.seclore.main.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.seclore.main.domain.BookDetails;
import com.seclore.main.domain.IssueDetails;
import com.seclore.main.domain.MemberDetails;
import com.seclore.main.service.BookServiceInterface;
import com.seclore.main.service.IssueServiceInterface;
import com.seclore.main.service.MemberServiceInterface;

@Controller
@RequestMapping("issuecrud")
public class IssueController {

	@Autowired
	private IssueServiceInterface issueService;// = (UserServiceInterface)
														// applicationContextWithoutXML.getBean("userService");

	@Autowired
	private MemberServiceInterface memberService;
	
	@Autowired
	private BookServiceInterface bookService;
	
	@RequestMapping("saveupdatedissue")
	public String saveUpdatedIssueDetails(IssueDetails issue) {
		System.out.println("Inside Save updated issue method" + issue.getIssue_id());
		boolean result = issueService.updateIssue(issue);
		System.out.println("Result: " + result);
		if (result) {
			return "redirect:/issuecrud/issues";
		}
		return "redirect:/issuecrud/issues";
	}

	@RequestMapping("updateissue/{issueId}")
	public ModelAndView updateIssueDetails(@PathVariable int issueId) {
		System.out.println("Inside Edit method");
		IssueDetails issue = issueService.getSingleIssue(issueId);

//		if (result) {
//			return "redirect:/issuecrud/issues";
//		}
//		return "redirect:/issuecrud/issues";

		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("issue", issue);
		modelAndView.setViewName("updateissue"); // This will be the name of the new issue jsp page

//		issue.setFirstName(null);
//		issue.setLastName(null);
//		issue.setSalary(0);
//		boolean result = issueService.updateIssueDetails(issue);
		return modelAndView;
	}

	@RequestMapping("deleteissue/{issueId}")
	public String deleteIssueDetails(@PathVariable int issueId) {
		System.out.println("Inside delete method");
		boolean result = issueService.removeIssue(issueId);
		if (result) {
			return "redirect:/issuecrud/issues";
		}
		return "redirect:/issuecrud/issues";
	}

	@RequestMapping("saveissue")
	public String saveIssueDetails(IssueDetails issue) {

		boolean result = issueService.addNewIssue(issue);
		if (result) {
			return "redirect:issues";
		}
		return "failure";
	}

	@RequestMapping("newissue")
	public ModelAndView showAddIssueDetails() {
		IssueDetails issue = new IssueDetails();
		List<MemberDetails> memberList = memberService.getAllMembers();
		List<BookDetails> bookList = bookService.getAllBooks();
		
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("issue", issue);
		modelAndView.addObject("memberList", memberList);
		modelAndView.addObject("bookList", bookList);
		
		modelAndView.setViewName("addnewissue"); // This will be the name of the new issue jsp page
		return modelAndView;
	}

	@RequestMapping("issues")
	public ModelAndView showIssueHome()// (HttpServletRequest request,HttpServletResponse response)
	{
		List<IssueDetails> issueList = issueService.getAllIssues();
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("issueList", issueList);
		modelAndView.setViewName("issuehome");
		System.out.println(issueList);
		return modelAndView;
	}
}

package com.seclore.main.controller.rest;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import com.seclore.main.domain.IssueDetails;
import com.seclore.main.domain.MemberDetails;
import com.seclore.main.domain.BookDetails;
import com.seclore.main.service.IssueServiceInterface;
import com.seclore.main.service.MemberServiceInterface;
import com.seclore.main.service.BookServiceInterface;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("issuecrudapi")
public class IssueControllerRest {

    @Autowired
    private IssueServiceInterface issueService;

    @Autowired
    private MemberServiceInterface memberService;

    @Autowired
    private BookServiceInterface bookService;

    @RequestMapping(value = "saveupdatedissue", method = RequestMethod.POST)
    public String saveUpdatedIssueDetails(IssueDetails issue) {
        System.out.println("Inside Save updated issue method" + issue.getIssue_id());
        boolean result = issueService.updateIssue(issue);
        System.out.println("Result: " + result);
        if (result) {
            return "redirect:/issuecrud/issues";
        }
        return "redirect:/issuecrud/issues";
    }

    @RequestMapping(value = "updateissue/{issueId}", method = RequestMethod.GET)
    public ModelAndView updateIssueDetails(@PathVariable int issueId) {
        System.out.println("Inside Edit method");
        IssueDetails issue = issueService.getSingleIssue(issueId);

        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("issue", issue);
        modelAndView.setViewName("updateissue"); // This will be the name of the new issue jsp page

        return modelAndView;
    }

    @RequestMapping(value = "deleteissue/{issueId}", method = RequestMethod.GET)
    public String deleteIssueDetails(@PathVariable int issueId) {
        System.out.println("Inside delete method");
        boolean result = issueService.removeIssue(issueId);
        if (result) {
            return "redirect:/issuecrud/issues";
        }
        return "redirect:/issuecrud/issues";
    }

    @RequestMapping(value = "saveissue", method = RequestMethod.POST)
    public String saveIssueDetails(IssueDetails issue) {

        boolean result = issueService.addNewIssue(issue);
        if (result) {
            return "redirect:/issuecrud/issues";
        }
        return "failure";
    }

    @RequestMapping(value = "newissue", method = RequestMethod.GET)
    public ModelAndView showAddIssueDetails() {
        IssueDetails issue = new IssueDetails();
        List<MemberDetails> memberList = memberService.getAllMembers();
        List<BookDetails> bookList = bookService.getAllBooks();

        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("issue", issue);
        modelAndView.addObject("memberList", memberList);
        modelAndView.addObject("bookList", bookList);

        modelAndView.setViewName("addnewissue"); // This will be the name of the new issue jsp page
        return modelAndView;
    }

    @RequestMapping(value = "issues", method = RequestMethod.GET)
    public ModelAndView showIssueHome() {
        List<IssueDetails> issueList = issueService.getAllIssues();
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("issueList", issueList);
        modelAndView.setViewName("issuehome");
        System.out.println(issueList);
        return modelAndView;
    }
}


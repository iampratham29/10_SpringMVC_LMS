/**
 * 
 */
package com.seclore.main.repository;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

import com.seclore.main.domain.IssueDetails;

/**
 * 
 */
public class IssueRowMapper implements RowMapper<IssueDetails> {
	
	public IssueDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
		String issue_id = rs.getString("issue_srl");
		int member_id = rs.getInt("member_id");
		int book_id = rs.getInt("book_id");
		Date issue_date = rs.getDate("issue_date");
		Date due_date = rs.getDate("issue_due_date");
		Date return_date = rs.getDate("issue_return_date");

		IssueDetails issue = new IssueDetails(issue_id, member_id, book_id, issue_date, due_date, return_date);
		return issue;
	}

}
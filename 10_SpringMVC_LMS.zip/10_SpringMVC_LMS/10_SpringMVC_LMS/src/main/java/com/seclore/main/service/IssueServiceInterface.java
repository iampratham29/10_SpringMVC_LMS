package com.seclore.main.service;
import java.util.List;

import com.seclore.main.domain.IssueDetails;

public interface IssueServiceInterface {
		public boolean addNewIssue(IssueDetails issue);
		public List<IssueDetails> getAllIssues();
		public IssueDetails getSingleIssue(int issueId);
		public boolean removeIssue(int issueId);
		public boolean updateIssue(IssueDetails issue);
}

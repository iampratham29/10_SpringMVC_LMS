package com.seclore.main.controller.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import com.seclore.main.domain.MemberDetails;
import com.seclore.main.service.MemberServiceInterface;

@Controller
@RequestMapping("membercrud")
public class MemberControllerRest {

    @Autowired
    private MemberServiceInterface memberService;

    @RequestMapping(value = "saveupdatedmember", method = RequestMethod.POST)
    public String saveUpdatedMemberDetails(MemberDetails member) {
        System.out.println("Inside Save updated member method" + member.getId());
        boolean result = memberService.updateMember(member);
        System.out.println("Result: " + result);
        if (result) {
            return "redirect:/membercrud/members";
        }
        return "redirect:/membercrud/members";
    }

    @RequestMapping(value = "updatemember/{memberId}", method = RequestMethod.GET)
    public ModelAndView updateMemberDetails(@PathVariable int memberId) {
        System.out.println("Inside Edit method");
        MemberDetails member = memberService.getSingleMember(memberId);

        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("member", member);
        modelAndView.setViewName("updatemember"); // This will be the name of the new member jsp page

        return modelAndView;
    }

    @RequestMapping(value = "deletemember/{memberId}", method = RequestMethod.GET)
    public String deleteMemberDetails(@PathVariable int memberId) {
        System.out.println("Inside delete method");
        boolean result = memberService.removeMember(memberId);
        if (result) {
            return "redirect:/membercrud/members";
        }
        return "redirect:/membercrud/members";
    }

    @RequestMapping(value = "savemember", method = RequestMethod.POST)
    public String saveMemberDetails(MemberDetails member) {

        boolean result = memberService.addNewMember(member);
        if (result) {
            return "redirect:/membercrud/members";
        }
        return "failure";
    }

    @RequestMapping(value = "newmember", method = RequestMethod.GET)
    public ModelAndView showAddMemberDetails() {
        MemberDetails member = new MemberDetails();

        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("member", member);
        modelAndView.setViewName("addnewmember"); // This will be the name of the new member jsp page
        return modelAndView;
    }

    @RequestMapping(value = "members", method = RequestMethod.GET)
    public ModelAndView showMemberHome() {
        List<MemberDetails> memberList = memberService.getAllMembers();
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("memberList", memberList);
        modelAndView.setViewName("memberhome");

        System.out.println(memberList);
        return modelAndView;
    }
}

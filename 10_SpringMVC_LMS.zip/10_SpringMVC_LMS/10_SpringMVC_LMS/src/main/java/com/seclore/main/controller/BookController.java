package com.seclore.main.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.seclore.main.domain.BookDetails;
import com.seclore.main.service.BookServiceInterface;

@Controller
@RequestMapping("bookcrud")
public class BookController {

	@Autowired
	private BookServiceInterface bookService;// = (UserServiceInterface)
														// applicationContextWithoutXML.getBean("userService");

	@RequestMapping("saveupdatedbook")
	public String saveUpdatedBookDetails(BookDetails book) {
		System.out.println("Inside Save updated book method" + book.getBookId());
		boolean result = bookService.updateBook(book);
		System.out.println("Result: " + result);
		if (result) {
			return "redirect:/bookcrud/books";
		}
		return "redirect:/bookcrud/books";
	}

	@RequestMapping("updatebook/{bookId}")
	public ModelAndView updateBookDetails(@PathVariable int bookId) {
		System.out.println("Inside Edit method");
		BookDetails book = bookService.getSingleBook(bookId);

//		if (result) {
//			return "redirect:/bookcrud/books";
//		}
//		return "redirect:/bookcrud/books";

		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("book", book);
		modelAndView.setViewName("updatebook"); // This will be the name of the new book jsp page

//		book.setFirstName(null);
//		book.setLastName(null);
//		book.setSalary(0);
//		boolean result = bookService.updateBookDetails(book);
		return modelAndView;
	}

	@RequestMapping("deletebook/{bookId}")
	public String deleteBookDetails(@PathVariable int bookId) {
		System.out.println("Inside delete method");
		boolean result = bookService.removeBook(bookId);
		if (result) {
			return "redirect:/bookcrud/books";
		}
		return "redirect:/bookcrud/books";
	}

	@RequestMapping("savebook")
	public String saveBookDetails(BookDetails book) {

		boolean result = bookService.addNewBook(book);
		if (result) {
			return "redirect:books";
		}
		return "failure";
	}

	@RequestMapping("newbook")
	public ModelAndView showAddBookDetails() {
		BookDetails book = new BookDetails();

		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("book", book);
		modelAndView.setViewName("addnewbook"); // This will be the name of the new book jsp page
		return modelAndView;
	}

	@RequestMapping("books")
	public ModelAndView showBookHome()// (HttpServletRequest request,HttpServletResponse response)
	{
		List<BookDetails> bookList = bookService.getAllBooks();
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("bookList", bookList);
		modelAndView.setViewName("bookhome");

		System.out.println(bookList);
		return modelAndView;
	}
}

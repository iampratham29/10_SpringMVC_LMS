/**
 * 
 */
package com.seclore.main.domain;

import java.sql.Date;

/**
 * 
 */
public class IssueDetails {
	private String issue_id;
	private int member_id;
	private int book_id;
	private Date issue_date;
	private Date due_date;
	private Date return_date;
	
	public IssueDetails() {
		// TODO Auto-generated constructor stub
	}
	
	

	public IssueDetails(String issue_id, int member_id, int book_id, Date issue_date, Date due_date,
			Date return_date) {
		super();
		this.issue_id = issue_id;
		this.member_id = member_id;
		this.book_id = book_id;
		this.issue_date = issue_date;
		this.due_date = due_date;
		this.return_date = return_date;
	}



	public String getIssue_id() {
		return issue_id;
	}

	public void setIssue_id(String issue_id) {
		this.issue_id = issue_id;
	}

	public int getMember_id() {
		return member_id;
	}

	public void setMember_id(int member_id) {
		this.member_id = member_id;
	}

	public int getBook_id() {
		return book_id;
	}

	public void setBook_id(int book_id) {
		this.book_id = book_id;
	}

	public Date getIssue_date() {
		return issue_date;
	}

	public void setIssue_date(Date issue_date) {
		this.issue_date = issue_date;
	}

	public Date getDue_date() {
		return due_date;
	}

	public void setDue_date(Date due_date) {
		this.due_date = due_date;
	}

	public Date getReturn_date() {
		return return_date;
	}

	public void setReturn_date(Date return_date) {
		this.return_date = return_date;
	}

	@Override
	public String toString() {
		return "IssueDetails [issue_id=" + issue_id + ", member_id=" + member_id + ", book_id=" + book_id
				+ ", issue_date=" + issue_date + ", due_date=" + due_date + ", return_date=" + return_date + "]";
	}
	
	
	
	
	

}

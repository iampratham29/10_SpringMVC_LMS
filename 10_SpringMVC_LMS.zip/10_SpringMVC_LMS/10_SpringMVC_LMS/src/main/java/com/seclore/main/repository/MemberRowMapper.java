package com.seclore.main.repository;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.seclore.main.domain.MemberDetails;

public class MemberRowMapper implements RowMapper<MemberDetails> {

	public MemberDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
		int id = rs.getInt("member_id");
		String name = rs.getString("member_name");
		String type = rs.getString("member_type");
		String status = rs.getString("member_status");
		int issue_count = rs.getInt("issue_count");
		MemberDetails memberDetails = new MemberDetails(id, name, type, status, issue_count);
		return memberDetails;
	}
}
package com.seclore.main.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.seclore.main.domain.MemberDetails;
import com.seclore.main.service.MemberServiceInterface;

@Controller
@RequestMapping("membercrud")
public class MemberController {

	@Autowired
	private MemberServiceInterface memberService;// = (UserServiceInterface)
														// applicationContextWithoutXML.getBean("userService");

	@RequestMapping("saveupdatedmember")
	public String saveUpdatedMemberDetails(MemberDetails member) {
		System.out.println("Inside Save updated member method" + member.getId());
		boolean result = memberService.updateMember(member);
		System.out.println("Result: " + result);
		if (result) {
			return "redirect:/membercrud/members";
		}
		return "redirect:/membercrud/members";
	}

	@RequestMapping("updatemember/{memberId}")
	public ModelAndView updateMemberDetails(@PathVariable int memberId) {
		System.out.println("Inside Edit method");
		MemberDetails member = memberService.getSingleMember(memberId);

//		if (result) {
//			return "redirect:/membercrud/members";
//		}
//		return "redirect:/membercrud/members";

		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("member", member);
		modelAndView.setViewName("updatemember"); // This will be the name of the new member jsp page

//		member.setFirstName(null);
//		member.setLastName(null);
//		member.setSalary(0);
//		boolean result = memberService.updateMemberDetails(member);
		return modelAndView;
	}

	@RequestMapping("deletemember/{memberId}")
	public String deleteMemberDetails(@PathVariable int memberId) {
		System.out.println("Inside delete method");
		boolean result = memberService.removeMember(memberId);
		if (result) {
			return "redirect:/membercrud/members";
		}
		return "redirect:/membercrud/members";
	}

	@RequestMapping("savemember")
	public String saveMemberDetails(MemberDetails member) {

		boolean result = memberService.addNewMember(member);
		if (result) {
			return "redirect:members";
		}
		return "failure";
	}

	@RequestMapping("newmember")
	public ModelAndView showAddMemberDetails() {
		MemberDetails member = new MemberDetails();

		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("member", member);
		modelAndView.setViewName("addnewmember"); // This will be the name of the new member jsp page
		return modelAndView;
	}

	@RequestMapping("members")
	public ModelAndView showMemberHome()// (HttpServletRequest request,HttpServletResponse response)
	{
		List<MemberDetails> memberList = memberService.getAllMembers();
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("memberList", memberList);
		modelAndView.setViewName("memberhome");

		System.out.println(memberList);
		return modelAndView;
	}
}
package com.seclore.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.seclore.main.domain.BookDetails;
import com.seclore.main.repository.BookRepositoryInterface;

@Component
public class BookService implements BookServiceInterface {

	@Autowired
	private BookRepositoryInterface bookrepository;
	
	@Override
	public boolean addNewBook(BookDetails book) {
		
		return bookrepository.addNewBook(book);
	}

	@Override
	public List<BookDetails> getAllBooks() {
		// TODO Auto-generated method stub
		return bookrepository.getAllBooks();
	}

	@Override
	public BookDetails getSingleBook(int bookId) {
		// TODO Auto-generated method stub
		return bookrepository.getSingleBook(bookId);
	}

	@Override
	public boolean removeBook(int bookId) {
		// TODO Auto-generated method stub
		return bookrepository.removeBook(bookId);
	}

	@Override
	public boolean updateBook(BookDetails book) {
		// TODO Auto-generated method stub
		return bookrepository.updateBook(book);
	}

}

package com.seclore.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.seclore.main.domain.IssueDetails;
import com.seclore.main.repository.IssueRepositoryInterface;

@Component
public class IssueService implements IssueServiceInterface {

	@Autowired
	private IssueRepositoryInterface issueRepository;
	
	@Override
	public boolean addNewIssue(IssueDetails issue) {
		// TODO Auto-generated method stub
		return issueRepository.addNewIssue(issue);
	}

	@Override
	public List<IssueDetails> getAllIssues() {
		// TODO Auto-generated method stub
		return issueRepository.getAllIssues();
	}

	@Override
	public IssueDetails getSingleIssue(int issueId) {
		// TODO Auto-generated method stub
		return issueRepository.getSingleIssue(issueId);
	}

	@Override
	public boolean removeIssue(int issueId) {
		// TODO Auto-generated method stub
		return issueRepository.removeIssue(issueId);
	}

	@Override
	public boolean updateIssue(IssueDetails issue) {
		// TODO Auto-generated method stub
		return issueRepository.updateIssue(issue);
	}

}

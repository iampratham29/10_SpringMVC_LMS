/**
 * 
 */
package com.seclore.main.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.seclore.main.domain.MemberDetails;

/**
 * 
 */
@Component
public class MemberRepository implements MemberRepositoryInterface {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	private static final String ADD_NEW_Member = "Insert into member_details(member_name, member_type, member_status, issue_count) values(?,?,?,0)";
	private static final String SELECT_ALL_Members = "Select * from member_details";
	private static final String SELECT_ONE_Member = "Select * from member_details Where member_id=?";
	private static final String REMOVE_ONE_Member = "DELETE from member_details Where member_id=?";
	private static final String UPDATE_Member = "Update member_details Set member_name=? , member_type=?, member_status=?  Where member_id=?";
	private static final String UPDATE_Member_ISSUE_COUNT = "Update member_details Set issue_count=? Where member_id=?";
	

	@Override
	public boolean addNewMember(MemberDetails member) {
		Object[] args = { member.getName(), member.getType(), member.getStatus() };
		int count = jdbcTemplate.update(ADD_NEW_Member, args);
		if (count > 0) {
			return true;
		}
		return false;
	}

	@Override
	public List<MemberDetails> getAllMembers() {
		// TODO Auto-generated method stub
		List<MemberDetails> memberList = jdbcTemplate.query(SELECT_ALL_Members, new MemberRowMapper());
		return memberList;
	}

	@Override
	public MemberDetails getSingleMember(int memberId) {
		// TODO Auto-generated method stub
		MemberDetails member = jdbcTemplate.queryForObject(SELECT_ONE_Member, new MemberRowMapper(), memberId);
		return member;
	}

	@Override
	public boolean removeMember(int memberId) {
		// TODO Auto-generated method stub
		int result = jdbcTemplate.update(REMOVE_ONE_Member, memberId);

		return result > 0;
	}

	@Override
	public boolean updateMember(MemberDetails member) {
		Object[] args = { member.getName(), member.getType(), member.getStatus(), member.getId() };
		int result = jdbcTemplate.update(UPDATE_Member, args);
		return result > 0;
	}
	
	public boolean updateMemberIssueCount(MemberDetails member) {
		Object[] args = { member.getIssue_count(), member.getId() };
		int result = jdbcTemplate.update(UPDATE_Member_ISSUE_COUNT, args);
		return result > 0;		
	}

}

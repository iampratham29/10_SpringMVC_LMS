package com.seclore.main.service;

import java.util.List;

import com.seclore.main.domain.BookDetails;

public interface BookServiceInterface {
	public boolean addNewBook(BookDetails book);
	public List<BookDetails> getAllBooks();
	public BookDetails getSingleBook(int bookId);
	public boolean removeBook(int bookId);
	public boolean updateBook(BookDetails book);
}

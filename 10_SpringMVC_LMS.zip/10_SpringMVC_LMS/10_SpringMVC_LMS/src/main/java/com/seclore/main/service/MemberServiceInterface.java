package com.seclore.main.service;
import java.util.List;

import com.seclore.main.domain.MemberDetails;

public interface MemberServiceInterface {
		public boolean addNewMember(MemberDetails member);
		public List<MemberDetails> getAllMembers();
		public MemberDetails getSingleMember(int memberId);
		public boolean removeMember(int memberId);
		public boolean updateMember(MemberDetails member);
}

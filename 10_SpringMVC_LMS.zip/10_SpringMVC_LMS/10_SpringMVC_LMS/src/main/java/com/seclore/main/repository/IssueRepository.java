/**
 * 
 */
package com.seclore.main.repository;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.seclore.main.domain.IssueDetails;

/**
 * 
 */
@Component
public class IssueRepository implements IssueRepositoryInterface {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	private static final String ADD_NEW_ISSUE = "Insert into issue_details(member_id, book_id, issue_date, issue_due_date, issue_return_date) values(?,?,?,?,?)";
	private static final String SELECT_ALL_ISSUES = "Select * from issue_details";
	private static final String SELECT_ONE_ISSUE = "Select * from issue_details Where issue_srl=?";
	private static final String REMOVE_ONE_ISSUE = "DELETE from issue_details Where issue_srl=?";
	private static final String UPDATE_ISSUE = "Update issue_details Set issue_date=? , issue_due_date=?, issue_return_date=?  Where issue_srl=?";

	@Override
	public boolean addNewIssue(IssueDetails issue) {
				
		Object[] args = { issue.getMember_id(), issue.getBook_id(), issue.getIssue_date(), issue.getDue_date(),
				issue.getReturn_date() };
		int count = jdbcTemplate.update(ADD_NEW_ISSUE, args);
		if (count > 0) {
			return true;
		}
		return false;
	}

	@Override
	public List<IssueDetails> getAllIssues() {
		// TODO Auto-generated method stub
		List<IssueDetails> issueList = jdbcTemplate.query(SELECT_ALL_ISSUES, new IssueRowMapper());
		return issueList;
	}

	@Override
	public IssueDetails getSingleIssue(int issueId) {
		// TODO Auto-generated method stub
		IssueDetails issue = jdbcTemplate.queryForObject(SELECT_ONE_ISSUE, new IssueRowMapper(), issueId);
		return issue;
	}

	@Override
	public boolean removeIssue(int issueId) {
		// TODO Auto-generated method stub
		int result = jdbcTemplate.update(REMOVE_ONE_ISSUE, issueId);

		return result > 0;
	}

	@Override
	public boolean updateIssue(IssueDetails issue) {
		Object[] args = { issue.getIssue_date(), issue.getDue_date(), issue.getReturn_date(), issue.getIssue_id() };
		int result = jdbcTemplate.update(UPDATE_ISSUE, args);
		return result > 0;
	}

}

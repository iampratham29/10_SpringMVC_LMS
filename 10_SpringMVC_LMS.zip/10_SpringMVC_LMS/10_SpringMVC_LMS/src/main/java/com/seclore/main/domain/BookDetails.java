/**
 * 
 */
package com.seclore.main.domain;

/**
 * 
 */
public class BookDetails {
	private int bookId;
	private String title;
	private String author;
	private boolean issuable; 
	
	public BookDetails() {
		// TODO Auto-generated constructor stub
	}

	public BookDetails(int bookId, String title, String author, boolean issuable) {
		super();
		this.bookId = bookId;
		this.title = title;
		this.author = author;
		this.issuable = issuable;
	}

	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public boolean isIssuable() {
		return issuable;
	}

	public void setIssuable(boolean issuable) {
		this.issuable = issuable;
	}

	@Override
	public String toString() {
		return "BookDetails [bookId=" + bookId + ", title=" + title + ", author=" + author + ", issuable=" + issuable
				+ "]";
	}
}
